n = ARGV[0].to_i + 1

n.times do |i|
    i.times do |j|
        print j += 1
    end
    print "\n"
end

#uso ruby ciclos_anidados1.rb 6
# el programa ingresa una lista de numeros consecutivos vertical.